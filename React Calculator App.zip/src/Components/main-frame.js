import React from "react";

const Button = props => {
  const buttonPressed = e => {
    props.buttonPressed(e.target.value);
  };
 
  
  return (
    <div id="background">
      < input type="text" id="result" value={props.valueInput} disabled />
      < input type="text" id="result" value={props.valueresult} disabled />
      <div id="main">
        <div id="first-row">
          <button value ="DEL" class="del-bg"  onClick={buttonPressed} id="delete">
            DEL
          </button>
          <button value ="C" class="del-bg" onClick={buttonPressed} id="delete">
            C
          </button>
          <button value="%" onClick={buttonPressed} class="btn-style operator opera-bg ">
            %
          </button>
          <button value="/" onClick={buttonPressed} class="btn-style opera-bg value align operator">
            /
          </button>
        </div>

        <div class="rows">
          <button
            onClick={buttonPressed}
            value="7"
            class="btn-style num-bg num first-child"
          >
            7
          </button>
          <button value="8" onClick={buttonPressed} class="btn-style num-bg num">
            8
          </button>
          <button value="9" onClick={buttonPressed} class="btn-style num-bg num">
            9
          </button>
          <button value="*" onClick={buttonPressed} class="btn-style opera-bg operator">
            *
          </button>
        </div>

        <div class="rows">
          <button value="4" onClick={buttonPressed} class="btn-style num-bg num first-child">
            4
          </button>
          <button value="5" onClick={buttonPressed} class="btn-style num-bg num">
            5
          </button>
          <button value="6" onClick={buttonPressed} class="btn-style num-bg num">
            6
          </button>
          <button value="+" onClick={buttonPressed} class="btn-style opera-bg operator">
            +
          </button>
        </div>

        <div class="rows">
          <button value="1" onClick={buttonPressed} class="btn-style num-bg num first-child">
            1
          </button>
          <button value="2"onClick={buttonPressed}  class="btn-style num-bg num">
            2
          </button>
          <button value="3"onClick={buttonPressed} class="btn-style num-bg num">
            3
          </button>
          <button value="-" onClick={buttonPressed} class="btn-style opera-bg operator">
            -
          </button>
        </div>

        <div class="rows">
          <button value="0" onClick={buttonPressed} class="num-bg zero" id="delete">
            0
          </button>
          <button value="." onClick={buttonPressed} class="btn-style num-bg  ">
            .
          </button>
          <button value="=" onClick={buttonPressed} id="equalbutton" class="eqn ">
            =
          </button>
        </div>
      </div>
    </div>
  );
};

export default Button;
