import React, { Component } from "react";
import ReactDOM from "react-dom";
import Button from "./Components/main-frame";
import "./styles.css";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // this empty string result is filled with values clciked and the final result
      result: " ",
      answer: " "
    };
    // bind the already present and the next clicked value in display screen
    this.buttonPressed = this.buttonPressed.bind(this);
  }

  buttonPressed = buttonPressed => {

    
    // evaluate the result for input in result current state using eval function(built in)
    if (buttonPressed === "=") {
      while (
        this.state.result.slice(-1) === "+" ||
        this.state.result.slice(-1) === "-" ||
        this.state.result.slice(-1) === "/" ||
        this.state.result.slice(-1) === "*" ||
        this.state.result.slice(-1) === "%"
      ) {
        this.state.result = this.state.result.slice(0, -1);
      }
      var calculateValue = eval(this.state.result);
      this.setState({
        answer: calculateValue
      });
      // clears the screen on clicking CE button
    }
    
    /*** else if(
      (this.state.result.slice(-1) === "+" ||
      this.state.result.slice(-1) === "-" ||
      this.state.result.slice(-1) === "/" ||
      this.state.result.slice(-1) === "*" ||
      this.state.result.slice(-1) === "%")
      &&

    (buttonPressed==="+" ||
    buttonPressed==="-" ||
    buttonPressed==="*" ||
    buttonPressed==="/" ||
    buttonPressed==="%" 
    )
    )
    
    }
***/
    
    else if (buttonPressed === "DEL") {
      this.setState({
        result: this.state.result.slice(0, -1),
        answer: " "
      });

      // clears the screen on clicking C button
    } else if (buttonPressed === "C") {
      this.setState({
        result: " ",
        answer: " "
      });
      // keep storing the clicked values in resukt string to display on screen
    } else {
      this.setState({
     
          
        result: this.state.result + buttonPressed
      });
    }
  };

  render() {
    return (
      <div className="App">
        <h1>CALCULATOR</h1>

        <Button
          // set input value 0 is nothing in pressed otherwise display current state of result string
          buttonPressed={this.buttonPressed}
          valueInput={this.state.result === " " ? 0 : this.state.result}
          valueresult={this.state.answer}
        />
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
